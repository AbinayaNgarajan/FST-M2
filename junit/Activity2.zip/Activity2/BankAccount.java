package Activity2;

public class BankAccount {
    public  Integer balance;

    public BankAccount(Integer initialBalance) {
        balance = initialBalance;
    }

    public Integer withdraw (Integer amount){



        if (balance < amount) {
            throw new NotEnoughFundsException(amount, balance);
        }
        balance -= amount;
        return balance;
    }
}

